/*
 * lb.c - Like the so popular Apache benchmark tool 'ab' but:
 *         o based on the Libevent
 *         o multi HTTP server
 *
 *        One or more HTTP servers to benchmark can be supplied:
 *         1. via arguments on the command line
 *         2. via a servers file using the -f switch on the command line
 *
 *        Command line arguments and file are mutually exclusive.
 *
 * -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=
 *                          _ _
 *                         | | |__
 *                         | | '_ \
 *                         | | |_) |
 *                         |_|_.__/
 *
 * 'lb' is a Libevent-based benchmarking tool for HTTP servers
 *
 *                     (C) Copyright 2009
 *         Rocco Carbone <rocco /at/ tecsiel /dot/ it>
 *
 * Released under the terms of 3-clause BSD License.
 * See included LICENSE file for details.
 *
 * -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=
 *
 */


/* Operating System header file(s) */
#include <stdlib.h>
#include <time.h>
#include <signal.h>
#include <getopt.h>

/* Private header file(s) */
#include "lb.h"
#include "version.h"


/* Version, authors and legal notice */
#define AUTHOR        "rocco@tecsiel.it"
#define COPYRIGHT     "Copyright (c) 2009 Rocco Carbone, Pisa, Italy"
#define LICENCE       "Released under 3-clause BSD license"
#define URL           "http://lb.tecsiel.it"
#define RELEASE_DATE  __DATE__


/* Global variable to keep run-time parameters all in one */
runtime_t * run = NULL;


/* What should be done when the program execution is interrupted by a signal */
static void on_interrupt (int sig)
{
  signal (sig, SIG_IGN);

  switch (sig)
    {
    case SIGINT:    /* ^C */
    case SIGQUIT:   /* quit */
    case SIGTERM:   /* terminate */
      printf ("\n%s: Normal termination: caught signal [%d]\n", run -> progname, sig);
      break;

    default:
      printf ("\n%s: Unexpected signal caught [%d]\n", run -> progname, sig);
      break;
    }

  /* Immediately exit the event loop */
  event_base_loopbreak (run -> base);
}


/* Initialize the Libevent and read the HTTP servers file in memory */
static int initialize (char * argv [])
{
  /* Initialize a new event base */
  run -> base = event_base_new ();

  /* Check first for one or more HTTP servers passed as arguments on the command line */
  if (* argv)
    {
      /* Attempt to resolve hostnames passed on the command line and keep them in an internal array */
      while (* argv)
	{
	  server_t * server = mkserver (* argv ++, run -> todo, run -> concurrency,
					run -> maxretry, run -> reply);
	  if (server)
	    /*
	     * Add the HTTP server to the array of those currently being
	     * benchmarked and increment its number for the next run
	     */
	    run -> httpargv = moreserver (run -> httpargv, server),
	      run -> httpargc ++;
	}
    }
  else if (run -> serversfile)
    {
      /* HTTP server supplied via a servers file, go to eat file in memory */
      if (slurp (run -> serversfile))
	return 1;
    }

  /* Check if at least one HTTP server has been specified for being benckmarked */
  if (! run -> httpargc)
    {
      printf ("%s: No HTTP server to benchmark. Exiting!\n", run -> progname);
      return 1;
    }

  return 0;
}


/* Terminate the Libevent */
static void terminate (struct event_base * base)
{
  /* Terminate the Libevent library */
  if (base)
    event_base_free (base);
}


/* Announce to the world! */
static void helloworld (char * progname, char * nodename)
{
  printf ("This is %s ver. %s (compiled %s) running on %s\n", progname, VERSION, RELEASE_DATE, nodename);
  printf ("%s - %s - %s\n\n", COPYRIGHT, LICENCE, URL);
}


/* Display the syntax for using this program */
static void usage (char * progname)
{
  printf ("%s %s, a very small and efficient Libevent-based benchmark tool for HTTP servers\n", progname, VERSION);
  printf ("Usage:\n");
  printf ("       %s [option(s)] url [url [url [url ... ]]]\n", progname);
  printf ("       %s [option(s)] -f serverfile\n", progname);
  printf ("\n");
  printf ("       Use the first syntax to specify any number of HTTP servers on the command line\n");
  printf ("       or the second to specify a file containing the lists of HTTP servers to benchmark.\n");
  printf ("\n");

  printf ("Startup:\n");
  printf ("   -h           show this help message and exit\n");
  printf ("   -v           show version number and exit\n");
  printf ("\n");

  printf ("Files:\n");
  printf ("   -f filename  file containing the list of servers to benchmark (default none)\n");

  printf ("   -n num       # of requests to perform for the benchmark session (default %d)\n", DEFAULT_REQUESTS);
  printf ("   -c num       # of multiple requests to perform at a time (default %d)\n", DEFAULT_CONCURRENCY);
  printf ("   -m num       max # of retries\n");
  printf ("   -r timeout   HTTP reply timeout\n");
  printf ("   -i timeout   initial timeout to start the benchmark session at (default immediately)\n");
  printf ("\n");

  printf ("    url syntax is [http://[userid:passwd@]]hostname:port/path\n");
  printf ("    take a look at the server template file for its syntax\n");
}


/* You are running this version of the software */
static void version (char * progname)
{
  printf ("%s ver. %s built on %s %s\n", progname, VERSION, __DATE__, __TIME__);
  printf ("%s\n", COPYRIGHT);
  printf ("%s - %s\n", LICENCE, URL);
}


/* Sirs and Ladies, here to you... lb!!! */
int main (int argc, char * argv [])
{
  int option;

  time_t msecs;
  time_t now;
  struct event_base * base;

  /* Exit code to the calling process */
  int exitcode = 0;

  /* Set unbuffered stdout */
  setvbuf (stdout, NULL, _IONBF, 0);

  /* Initialize run-time variables to default values */
  run = defaultrun (argv [0]);

#define OPTSTRING "hvqf:n:c:m:r:i:"
  while ((option = getopt (argc, argv, OPTSTRING)) != EOF)
    {
      switch (option)
        {
        default: usage (run -> progname); return 1;

        case 'h': usage (run -> progname);   return 0;
        case 'v': version (run -> progname); return 0;
        case 'q': run -> quiet = 1; break;                                           /* Quiet output                         */

        case 'f': run -> serversfile = safedup (optarg, run -> serversfile); break;  /* HTTP servers file                    */

	case 'n': run -> todo = atoi (optarg); break;                                /* Total # of requests - 0 unlimited    */

	case 'c': run -> concurrency = atoi (optarg);                                /* # of concurrent requests - 0 illegal */
	  if (! run -> concurrency)
	    {
	      printf ("%s: illegal # of concurrency requests [%s]\n", run -> progname, optarg);
	      exitcode = 1;
	      goto bye;
	    }
	  break;

	case 'm': run -> maxretry = atoi (optarg); break;                            /* Max # of retries - 0 none            */

	case 'r': run -> reply = atomsec (optarg);                                   /* HTTP Reply timeout - 0 illegal       */
	  if (run -> reply <= 0)
	    {
	      printf ("%s: illegal timeout [%s]\n", run -> progname, optarg);
	      exitcode = 1;
	      goto bye;
	    }
	  break;

	case 'i': msecs = atomsec (optarg);                                          /* Initial delay timeout                */
	  if (msecs == -1)
	    {
	      printf ("%s: illegal timeout [%s]\n", run -> progname, optarg);
	      exitcode = 1;
	      goto bye;
	    }
	  msecstotv (msecs, & run -> initial_tv);
	  break;
	}
    }

  /* Move pointer to optional arguments (if any) passed on the command line */
  argv = & argv [optind];

  /* Check for mandatory arguments */
  if (! * argv && ! run -> serversfile)
    {
      printf ("%s: missing argument\n", run -> progname);
      usage (run -> progname);
      exitcode = 1;
      goto bye;
    }
  else if (* argv && run -> serversfile)
    {
      printf ("%s: command line arguments and file are mutually exclusive\n", run -> progname);
      usage (run -> progname);
      exitcode = 1;
      goto bye;
    }

  /* Not not allow a concurrency greater than the number of requests */
  if (run -> todo && run -> concurrency > run -> todo)
    run -> concurrency = run -> todo;

  /* Hey boys, lb speaking! */
  if (! run -> quiet)
    helloworld (run -> progname, run -> nodename);

  /* Initialize the Libevent with a new main base event, and optionally read the HTTP servers file in memory */
  if (initialize (argv))
    {
      exitcode = 1;
      goto bye;
    }

  /* Install signal handlers */
  signal (SIGPIPE, SIG_IGN);              /* Ignore writes to connections that have been closed at the other end */
  signal (SIGINT,  on_interrupt);         /* ^C */
  signal (SIGQUIT, on_interrupt);         /* quit */
  signal (SIGTERM, on_interrupt);         /* terminate */

  /* Define the callback and add the timer to start benchmarking after an initial delay timeout */
  evtimer_assign (& run -> bench_evt, run -> base, benchmark_cb, NULL);
  evtimer_add (& run -> bench_evt, & run -> initial_tv);

  /* Event dispatching loop */
  event_base_dispatch (run -> base);

  now = time (NULL);
  if (! run -> quiet)
    printf ("%s: #%d HTTP server%s - benchmark session stopped at %24.24s\n\n",
	    run -> progname, run -> httpargc, run -> httpargc > 1 ? "s" : "", ctime (& now));

  /* Print per server statistics information */
  lbstats (run -> httpargv);

 bye:

  base = run -> base;

  /* Release resources and memory */
  nomorerun (run);

  /* Terminate the main base event */
  terminate (base);

  return exitcode;
}
