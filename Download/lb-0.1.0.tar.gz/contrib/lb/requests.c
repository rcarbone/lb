/*
 * requests.c - Utilities to keep in memory libevent-based HTTP requests
 *
 * -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=
 *                          _ _
 *                         | | |__
 *                         | | '_ \
 *                         | | |_) |
 *                         |_|_.__/
 *
 * 'lb' is a Libevent-based benchmarking tool for HTTP servers
 *
 *                     (C) Copyright 2009
 *         Rocco Carbone <rocco /at/ tecsiel /dot/ it>
 *
 * Released under the terms of the BSD License.  See included
 * COPYING file for details.
 *
 * -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=
 *
 */


/* Operating System header file(s) */
#include <stdlib.h>
#include <string.h>
#include <values.h>
#include <netdb.h>
#include <arpa/inet.h>

/* Private header file(s) */
#include "lb.h"


/* Allocate and initialize new request for outgoing benchmarking activities */
req_t * mkreq (struct event_base * base, server_t * server)
{
  req_t * request = calloc (sizeof (req_t), 1);

  /* Set the time the request was created */
  gettimeofday (& request -> created, NULL);

  /* Bind the server to the request */
  request -> server = server;

  /* Define a new connection with the HTTP server */
  request -> evcon = evhttp_connection_base_new (base, server -> uri -> hostname, atoi (server -> uri -> port));

  /* Sets the timeout for events related to this connection */
  evhttp_connection_set_timeout (request -> evcon, server -> reply_tv . tv_sec);

  /* Sets the retry limit for this connection - -1 repeats indefinitely */
  evhttp_connection_set_retries (request -> evcon, server -> maxretry);

  /* Creates a new request object that needs to be filled in with the request parameters */
  request -> evreq = evhttp_request_new (reply_cb, request);

  /* Add HTTP 'Host' header to the request parameters */
  evhttp_add_header (request -> evreq -> output_headers, "Host", server -> uri -> hostname);

  return request;
}


/* Free allocated memory used to keep a HTTP request */
void rmreq (void * req)
{
  req_t * r = (req_t *) req;
  if (! r)
    return;

  /* Free the http connection */
  if (r -> evcon)
    evhttp_connection_free (r -> evcon);

  free (r);
}


/* Add an item to the array */
req_t ** morereq (req_t * argv [], req_t * item)
{
  return (req_t **) vamore ((void **) argv, item);
}


/* Remove an item from the array */
req_t ** lessreq (req_t * argv [], req_t * item, void (* rmitem) (void *))
{
  return (req_t **) valess ((void **) argv, item, rmitem);
}


/* Free the whole array */
req_t ** cleanupreq (req_t * argv [], void (* rmitem) (void *))
{
  return (req_t **) vacleanup ((void **) argv, rmitem);
}
